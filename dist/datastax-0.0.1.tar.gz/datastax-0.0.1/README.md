# datastax

## Introduction

- This is a very simple yet powerful project to implement day to day data structures.
- A pure implementation of Python in representing Trees and Linkedlists in basic command prompt
- It helps visualize each data structure for better understanding
- Students can be beneficial in using this Package
- This project is still under construction

## Installation

Use the python package manager [pip](https://pip.pypa.io/en/stable/) to install datastax.

```bash
pip install datastax
```

## Usage