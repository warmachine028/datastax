from datastax.linkedlists.linked_list import LinkedList, Node
